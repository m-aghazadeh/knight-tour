import {useEffect, useMemo, useRef, useState} from "react";
import Chessboard from "./components/Chessboard";
import Controls from "./components/Controls";
import Legend from "./components/Legend";
import Badge from "@/components/Badge";
import {knightsTour} from "./algorithms/knightsTour";
import type {Coord, TourState} from "./types";
import "./index.css";

export default function App() {
    const [n, setN] = useState(8);
    const [start, setStart] = useState<Coord | null>(null);
    const [state, setState] = useState<TourState>("idle");
    const [path, setPath] = useState<Coord[] | null>(null);
    const [idx, setIdx] = useState(0);
    const [speedMs, setSpeedMs] = useState(120);

    const timerRef = useRef<number | null>(null);

    const canPlay = path !== null && path.length > 0;

    // اگر سایز عوض شد، ریست
    useEffect(() => {
        resetAll();
    }, [n]);

    function resetAll() {
        stopTimer();
        setState("idle");
        setPath(null);
        setIdx(0);
    }

    function stopTimer() {
        if (timerRef.current !== null) {
            window.clearInterval(timerRef.current);
            timerRef.current = null;
        }
    }

    function onPickStart(c: Coord) {
        if (state === "playing") return;
        setStart(c);
        setState("idle");
        setPath(null);
        setIdx(0);
    }

    function onCompute() {
        if (!start) return;
        setState("computing");
        // محاسبه‌ی مسیر (همین Thread کافی است—سبک است)
        const tour = knightsTour(n, start);
        if (tour) {
            setPath(tour);
            setIdx(0);
            setState("ready");
        } else {
            setPath(null);
            setIdx(0);
            setState("failed");
        }
    }

    function onPlayPause() {
        if (!path) return;
        if (state === "playing") {
            stopTimer();
            setState("paused");
            return;
        }
        setState("playing");
        stopTimer();
        timerRef.current = window.setInterval(() => {
            setIdx(prev => {
                if (!path) return prev;
                if (prev >= path.length - 1) {
                    stopTimer();
                    setState("done");
                    return prev;
                }
                return prev + 1;
            });
        }, speedMs);
    }

    function onReset() {
        stopTimer();
        setIdx(0);
        if (path) setState("ready");
        else setState("idle");
    }

    // اگر سرعت تغییر کرد و در حال پخش بودیم، تایمر را دوباره بساز
    useEffect(() => {
        if (state === "playing") {
            stopTimer();
            timerRef.current = window.setInterval(() => {
                setIdx(prev => {
                    if (!path) return prev;
                    if (prev >= path.length - 1) {
                        stopTimer();
                        setState("done");
                        return prev;
                    }
                    return prev + 1;
                });
            }, speedMs);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [speedMs]);

    const statusText = useMemo(() => {
        switch (state) {
            case "idle":
                return "Choose a start square, then Compute.";
            case "computing":
                return "Computing tour…";
            case "ready":
                return "Tour ready. Press Play.";
            case "playing":
                return "Playing…";
            case "paused":
                return "Paused.";
            case "done":
                return "Done!";
            case "failed":
                return "No tour found (try another start/size).";
            default:
                return "";
        }
    }, [state]);

    return (
        <div className="page">
            <header className="header">
                <h1>Knight’s Tour — React + TS</h1>
                <Badge>{statusText}</Badge>
            </header>

            <div className="layout">
                <div className="left">
                    <Chessboard
                        n={n}
                        start={start}
                        onPickStart={onPickStart}
                        path={path ? path.slice(0, idx + 1) : null}
                        currentIndex={idx}
                    />
                    <div style={{marginTop: 12, opacity: 0.8}}>
                        <Legend />
                    </div>
                </div>

                <div className="right">
                    <Controls
                        n={n}
                        onSizeChange={setN}
                        speedMs={speedMs}
                        onSpeedChange={setSpeedMs}
                        canPlay={!!path}
                        playing={state === "playing"}
                        onCompute={onCompute}
                        onPlayPause={onPlayPause}
                        onReset={onReset}
                    />

                    <div className="card">
                        <h3>How to use</h3>
                        <ol>
                            <li>روی هر خانه کلیک کنید تا «شروع» تعیین شود.</li>
                            <li>دکمه <em>Compute Tour</em> را بزنید تا مسیر حساب شود.</li>
                            <li>با <em>Play</em> انیمیشن مسیر را ببینید. سرعت را با اسلایدر عوض کنید.
                            </li>
                            <li><em>Reset</em> فقط انیمیشن را به قدم ۱ برمی‌گرداند.</li>
                        </ol>
                    </div>

                    <div className="card">
                        <h3>About the algorithm</h3>
                        <p>
                            از قاعده‌ی Warnsdorff استفاده شده: در هر قدم به خانه‌ای می‌رویم که کمترین تعداد ادامه‌مسیرهای ممکن را دارد (کمترین «درجه»). برای ۸×۸ معمولاً همیشه جواب می‌دهد و خیلی سریع است.
                        </p>
                    </div>
                </div>
            </div>

            <footer className="footer">
                Made with ❤️ — share & star on GitHub!
            </footer>
        </div>
    );
}
