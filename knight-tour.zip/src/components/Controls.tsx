import React from "react";

type Props = {
    n: number;
    onSizeChange: (n: number) => void;
    speedMs: number;
    onSpeedChange: (ms: number) => void;
    canPlay: boolean;
    playing: boolean;
    onCompute: () => void;
    onPlayPause: () => void;
    onReset: () => void;
};

export default function Controls({
                                     n, onSizeChange, speedMs, onSpeedChange,
                                     canPlay, playing, onCompute, onPlayPause, onReset
                                 }: Props) {
    return (
        <div className="panel">
            <div className="row">
                <label>
                    Board Size:
                    <select
                        value={n}
                        onChange={(e) => onSizeChange(parseInt(e.target.value, 10))}
                        style={{ marginLeft: 8 }}
                    >
                        {[5,6,7,8,9,10].map(v => <option key={v} value={v}>{v}×{v}</option>)}
                    </select>
                </label>

                <label style={{ marginLeft: 16 }}>
                    Speed (ms/step):
                    <input
                        type="range"
                        min={30} max={800} step={10}
                        value={speedMs}
                        onChange={(e) => onSpeedChange(parseInt(e.target.value, 10))}
                        style={{ width: 160, marginLeft: 8, verticalAlign: "middle" }}
                    />
                    <span style={{ marginLeft: 8 }}>{speedMs}</span>
                </label>
            </div>

            <div className="row" style={{ gap: 8 }}>
                <button onClick={onCompute}>Compute Tour</button>
                <button onClick={onPlayPause} disabled={!canPlay}>
                    {playing ? "Pause" : "Play"}
                </button>
                <button onClick={onReset}>Reset</button>
            </div>
        </div>
    );
}
