
export default function Legend() {
    const item = (color: string, label: string) => (
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{
          width: 14, height: 14, borderRadius: 4, background: color,
          border: "1px solid rgba(0,0,0,0.2)"
      }} />
            <span style={{ fontSize: 12 }}>{label}</span>
        </div>
    );

    return (
        <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            {item("#ffd54f", "خانه شروع")}
            {item("#a5d6a7", "خانه‌های طی‌شده")}
            {item("#ef9a9a", "خانه‌ی فعلی")}
            {item("#eeeeee", "خانه‌ی طی‌نشده")}
        </div>
    );
}
